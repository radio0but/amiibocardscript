#include <stdlib.h>

int main() {

    system("install_dependencies.bat");
    return 0;
}
