#include <stdlib.h>

int main() {

    system("python.exe start.py");
    return 0;
}
